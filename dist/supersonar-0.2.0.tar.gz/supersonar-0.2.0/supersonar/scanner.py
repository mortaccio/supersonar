from __future__ import annotations

from pathlib import Path

from supersonar.models import CoverageData, Issue, ScanResult
from supersonar.rules import PythonRuleEngine


def _should_exclude(path: Path, excludes: list[str]) -> bool:
    parts = set(path.parts)
    return any(ex in parts for ex in excludes)


def scan_path(root: str, excludes: list[str], coverage: CoverageData | None = None) -> ScanResult:
    root_path = Path(root).resolve()
    rule_engine = PythonRuleEngine()
    issues: list[Issue] = []
    files_scanned = 0

    for file_path in root_path.rglob("*.py"):
        if _should_exclude(file_path, excludes):
            continue
        files_scanned += 1
        issues.extend(rule_engine.run(file_path))

    return ScanResult(issues=issues, files_scanned=files_scanned, coverage=coverage)
