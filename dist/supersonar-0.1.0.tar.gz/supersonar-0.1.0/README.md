# supersonar

`supersonar` is a lightweight, SonarQube-inspired static analysis CLI for Python projects.
It is designed for local use and CI pipelines via `pip install`.

## Quick start

```bash
pip install .
supersonar scan . --format json
```

## CI usage

```bash
pip install supersonar
supersonar scan . --format sarif --out reports/supersonar.sarif --fail-on high
```

## Config (`supersonar.toml`)

```toml
[scan]
exclude = [".git", ".venv", "venv", "build", "dist", "__pycache__"]

[quality_gate]
fail_on = "high"
max_issues = 0

[report]
format = "json"
```

## Rule coverage (MVP)

- `SS001` - dangerous `eval` / `exec`
- `SS002` - broad `except Exception` or bare `except`
- `SS003` - hardcoded secret-like tokens
- `SS004` - `TODO` / `FIXME` markers
