from __future__ import annotations

from pathlib import Path
import tempfile
import unittest

from supersonar.scanner import scan_path


class ScannerTests(unittest.TestCase):
    def test_detects_eval_issue(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            sample = root / "sample.py"
            sample.write_text("value = eval('2+2')\n", encoding="utf-8")

            result = scan_path(str(root), excludes=[])
            rule_ids = {issue.rule_id for issue in result.issues}

            self.assertIn("SS001", rule_ids)
            self.assertEqual(result.files_scanned, 1)

    def test_excludes_directory(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            src = root / "src"
            src.mkdir()
            ignored = root / "venv"
            ignored.mkdir()
            (src / "ok.py").write_text("print('ok')\n", encoding="utf-8")
            (ignored / "bad.py").write_text("eval('x')\n", encoding="utf-8")

            result = scan_path(str(root), excludes=["venv"])
            rule_ids = {issue.rule_id for issue in result.issues}

            self.assertNotIn("SS001", rule_ids)
            self.assertEqual(result.files_scanned, 1)


if __name__ == "__main__":
    unittest.main()

