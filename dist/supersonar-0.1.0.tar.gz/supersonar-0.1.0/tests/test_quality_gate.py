from __future__ import annotations

import unittest

from supersonar.models import Issue, ScanResult
from supersonar.quality_gate import evaluate_gate


class QualityGateTests(unittest.TestCase):
    def test_fails_on_severity_threshold(self) -> None:
        result = ScanResult(
            issues=[
                Issue(
                    rule_id="SS001",
                    title="t",
                    severity="critical",
                    message="m",
                    file_path="x.py",
                    line=1,
                    column=1,
                )
            ],
            files_scanned=1,
        )
        passed, reasons = evaluate_gate(result, fail_on="high")
        self.assertFalse(passed)
        self.assertTrue(reasons)

    def test_passes_under_max_issues(self) -> None:
        result = ScanResult(issues=[], files_scanned=1)
        passed, reasons = evaluate_gate(result, max_issues=0)
        self.assertTrue(passed)
        self.assertEqual(reasons, [])


if __name__ == "__main__":
    unittest.main()

